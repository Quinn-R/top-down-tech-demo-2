clear

clear

clear

g++ main.cpp inc/common.h -lsfml-graphics -lsfml-window -lsfml-system

cd obj

./run

cd ..
